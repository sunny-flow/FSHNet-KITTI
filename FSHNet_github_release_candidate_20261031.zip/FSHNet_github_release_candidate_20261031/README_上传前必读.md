# GitHub 代码包：上传前必读

这是从用户提供的 ZIP 中整理的**私下待审核版本**，尚未上传 GitHub，也未完成独立 CUDA 安装和端到端复现。请先核对 `README.md` 和 `release_notes/`。

## 已整理

- 保留 `pcdet/` 源代码、CUDA/C++ 扩展源码、训练和评价入口、原 ZIP 中的配置、测试和文档，保留根目录及第三方许可文件和上游署名。
- 保留 KITTI 的 train、val、test 划分 ID 列表；不包含原始点云、图像、标签、数据库、权重、实验日志、预编译 `.so` 或 build。划分文件的来源和可再分发权仍需作者确认。
- 已明确记录优化器修复、一个 KITTI 评价脚本的相对导入语法修复，以及发布路径适配。所有变更见 `release_notes/release_changes.json`；原始文件哈希见 `archive_source_manifest.csv`。
- 原包包含三个模块的代码，但没有与论文完整八组历史运行逐一绑定的 YAML、权重及选模/评估记录，不能据此宣称 R2-15 已完成。

## 尚需作者处理

1. 审查全部代码中的版权、第三方授权、敏感信息及 KITTI 划分的再分发权；根 LICENSE 并不能自动覆盖所有第三方材料。
2. 在独立 Linux + CUDA 环境核验依赖、编译扩展、准备真实数据，逐项运行训练和评估流程。原 `requirements.txt` 是历史包清单而非已验证锁文件。
3. 从可追溯来源补齐论文使用的真实配置、split/seed、选模和评估脚本、权重身份及八组结果。对后续受控配置与历史版本分别标识，不可混称。
4. 审核公开仓库内容后再发布，并记录真实可访问 URL、提交号或 release。整理完成不等于审稿人已经能访问。

使用新的空仓库，在解压后的本目录执行（替换您自己的 GitHub 仓库地址）：

```bash
git init
git add .
git status
git commit -m "Add FSHNet research code release candidate"
git branch -M main
git remote add origin <YOUR_GITHUB_REPOSITORY_URL>
git push -u origin main
```

上传前检查 `git status`，确保没有意外加入数据、权重和秘密；如果服务器提示认证，使用您自行配置的 GitHub 认证方式。此说明没有执行上传。
